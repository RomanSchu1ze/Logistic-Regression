## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ------------------------------------------------------------------------
# Loading packages ----
library(myLogit)
library(ggplot2)
library(gridExtra)

## ----  fig.height = 4, fig.width = 6-------------------------------------

# Plot linear model
plot1 <- ggplot2::ggplot(myLogit::myData, ggplot2::aes(y = Survived, x = Fare)) + 
  ggplot2::geom_smooth(method = "lm") + 
  ggplot2::ggtitle("Linear Regression") + 
  ggplot2::labs(y = "Probabilty(Survived)") 

# Plot logistic regression
plot2 <- ggplot2::ggplot(myData, ggplot2::aes(y = Survived, x = Fare)) + 
  ggplot2::geom_smooth(method = "glm", method.args = list(family = "binomial")) + 
  ggplot2::ggtitle("Logistic Regression") + 
  ggplot2::labs(y = "Probabilty(Survived)") 

# Plot next to each other using gridExtra package 
grid.arrange(plot1, plot2, ncol = 2)


## ------------------------------------------------------------------------
# Fisher scoring algorithm ----
fScore <- function(X, y, maxIter = 100, rate = 1, accuracy = 0.01, ...) {
  # Initial beta vector
  beta <- rep(0, ncol(X))
  # Starting value for change in beta
  delta <- 1
  #iteration counter
  iter <- 0
  # convergence
  convergence <- FALSE
  # probability
  p <- logistic(X %*% beta)
  # empty vecotr to store log-Likelihood
  l <- c()
  # Optimization using while loop with two conditions
  while (convergence == FALSE && iter <= maxIter) {
    # Update iteration
    iter <- iter + 1
    # Calculate log - Likelihood for each combination
    l[iter] <- logLike(X, y, beta)
    # update beta
    betaNew <- beta + rate * solve(fisher(X, p)) %*% score(X, y, beta)
    pnew <- logistic(X %*% betaNew)
    # Change in beta
    delta <- abs(betaNew - beta)
    beta <- betaNew
    p <- pnew
    # check convergence condition
    if (sum(delta) < accuracy) {
      convergence <- TRUE
      break
    }
  }
  # if no convergence...
  if (convergence == FALSE) {
    stop(paste(iter, "iterations reached without convergence. Increase maxIter?"))
  }
  # return list with results
  return(list(coefficients = beta,
              prob = as.vector(p),
              iterations = iter,
              logLikelihood = l,
              convergence = convergence))
}



## ------------------------------------------------------------------------
# Example ---- 
set.seed(1)
X <- replicate(2, rnorm(100))
# Add a vector of ones as first column to estimate Intercept
X <- cbind(1, X)
z <- 2 * X[, 2] + 3 * X[, 3]
# The function logstic calculates the estimated probabilities according to equation (9)
y <- rbinom(100, 1, logistic(z))
fScore(X, y)

## ------------------------------------------------------------------------
# dataset  
help(myData)
head(myData)

## ------------------------------------------------------------------------
# Estimate model
mod <- logit(Survived ~ Pclass + Age + Sex , data = myData)
# Check class
class(mod)
# Print 
print(mod)

## ------------------------------------------------------------------------
# Summary of model 
summary(mod)

## ------------------------------------------------------------------------
# Estimate same model using glm() function
test <- stats::glm(Survived ~ Pclass + Age + Sex , data = myData, family = binomial)
summary(test)

## ------------------------------------------------------------------------
# Predict model
head(predict(mod, t = 0.5))

# Compare predictions results
all(round(predict(mod)[, 1], 7) %in% round(stats::predict(test), 7))


## ---- fig.height = 3.5, fig.width = 3.5----------------------------------
# Plot 
plot(mod)

## ---- fig.width = 4------------------------------------------------------
# ROC curve for model mod
obj <- ggRoc(mod$y, mod$prob)
a <- plot(obj)

# Add ROC curve for model which only includes Pclass as a predictor
mod1 <- logit(Survived ~ Pclass, data = myData)
obj1 <- ggRoc(mod1$y, mod1$prob)

# Overlay existing plot a  
a <- a + ggplot2::geom_line(data = obj1[[1]], 
                            ggplot2::aes(x = obj1[[1]]$falsePositive, 
                                         y = obj1[[1]]$truePositive),
                            colour = "red")
# Plot a
a

